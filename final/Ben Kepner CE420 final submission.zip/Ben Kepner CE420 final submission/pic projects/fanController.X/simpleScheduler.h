/* 
 * File:   simpleScheduler.h
 * Author: ben
 *
 * Created on April 22, 2019, 11:27 AM
 */

#ifndef SIMPLESCHEDULER_H
#define	SIMPLESCHEDULER_H

#ifdef	__cplusplus
extern "C" {
#endif

    


    
void starScheduler(void (*secondCallback) ());
    


#ifdef	__cplusplus
}
#endif

#endif	/* SIMPLESCHEDULER_H */

